"use client";
import React from "react";

function MainComponent() {
  const { data: user } = useUser();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [cursorVisible, setCursorVisible] = useState(false);
  const [clickEffect, setClickEffect] = useState([]);

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      const navHeight = 80; // Chiều cao của thanh navigation
      const sectionTop = section.offsetTop - navHeight;
      window.scrollTo({
        top: sectionTop,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 100;
      setIsVisible(scrolled);
    };

    const handleMouseMove = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      setCursorVisible(true);
    };

    const handleMouseLeave = () => {
      setCursorVisible(false);
    };

    const handleClick = (e) => {
      const newEffect = {
        id: Date.now(),
        x: e.clientX,
        y: e.clientY,
      };
      setClickEffect((prev) => [...prev, newEffect]);

      setTimeout(() => {
        setClickEffect((prev) =>
          prev.filter((effect) => effect.id !== newEffect.id)
        );
      }, 1000);
    };

    if (window.innerWidth > 768) {
      window.addEventListener("mousemove", handleMouseMove);
      window.addEventListener("mouseleave", handleMouseLeave);
      window.addEventListener("click", handleClick);
    }

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (window.innerWidth > 768) {
        window.removeEventListener("mousemove", handleMouseMove);
        window.removeEventListener("mouseleave", handleMouseLeave);
        window.removeEventListener("click", handleClick);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {clickEffect.map((effect) => (
        <div
          key={effect.id}
          className="fixed pointer-events-none z-50"
          style={{
            left: effect.x,
            top: effect.y,
            transform: "translate(-50%, -50%)",
          }}
        >
          <div className="animate-click-ring-1" />
          <div className="animate-click-ring-2" />
          <div className="animate-click-ring-3" />
        </div>
      ))}

      {cursorVisible && (
        <>
          <div
            className="hidden md:block fixed w-8 h-8 rounded-full bg-[#357AFF]/20 pointer-events-none transition-all duration-200 z-50 mix-blend-difference"
            style={{
              left: mousePosition.x - 16,
              top: mousePosition.y - 16,
              transform: "scale(1.5)",
              backdropFilter: "invert(1)",
            }}
          />
          <div
            className="hidden md:block fixed w-4 h-4 rounded-full bg-[#357AFF]/40 pointer-events-none transition-all duration-150 z-50"
            style={{
              left: mousePosition.x - 8,
              top: mousePosition.y - 8,
              transform: "scale(1)",
              mixBlendMode: "difference",
            }}
          />
          <div
            className="hidden md:block fixed w-2 h-2 rounded-full bg-white pointer-events-none z-50"
            style={{
              left: mousePosition.x - 1,
              top: mousePosition.y - 1,
              mixBlendMode: "difference",
            }}
          />
        </>
      )}

      <nav
        className={`fixed top-0 z-40 w-full bg-white/80 shadow-lg backdrop-blur-md transition-all duration-300 ${
          isVisible ? "translate-y-0" : "-translate-y-1"
        }`}
      >
        <div className="mx-auto max-w-7xl px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => scrollToSection("home")}
              className="text-2xl font-bold text-[#357AFF] hover:scale-105 transition-transform"
            >
              Portfolio
            </button>

            <div className="hidden space-x-8 md:flex">
              {[
                { id: "gioithieu", text: "Giới thiệu" },
                { id: "skills", text: "Kỹ năng" },
                { id: "experience", text: "Kinh nghiệm" },
                { id: "contact", text: "Liên hệ" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="relative text-gray-600 hover:text-[#357AFF] transition-colors group"
                >
                  {item.text}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#357AFF] transition-all duration-300 group-hover:w-full"></span>
                </button>
              ))}
            </div>

            <button
              className="md:hidden relative group"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <div
                className={`w-6 h-1 bg-gray-600 transition-all duration-300 ${
                  isMenuOpen ? "rotate-45 translate-y-2" : ""
                }`}
              ></div>
              <div
                className={`w-6 h-1 bg-gray-600 my-1 transition-opacity duration-300 ${
                  isMenuOpen ? "opacity-0" : ""
                }`}
              ></div>
              <div
                className={`w-6 h-1 bg-gray-600 transition-all duration-300 ${
                  isMenuOpen ? "-rotate-45 -translate-y-2" : ""
                }`}
              ></div>
            </button>
          </div>

          <div
            className={`md:hidden transition-all duration-300 ${
              isMenuOpen
                ? "opacity-100 h-auto mt-4 pb-4"
                : "opacity-0 h-0 overflow-hidden"
            }`}
          >
            {[
              { id: "gioithieu", text: "Giới thiệu" },
              { id: "skills", text: "Kỹ năng" },
              { id: "experience", text: "Kinh nghiệm" },
              { id: "contact", text: "Liên hệ" },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  scrollToSection(item.id);
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left py-2 text-gray-600 hover:text-[#357AFF] hover:pl-2 transition-all duration-300"
              >
                {item.text}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <section
        id="gioithieu"
        className="flex min-h-screen items-center justify-center pt-16 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-indigo-50/50 animate-gradient"></div>
        <div className="mx-auto max-w-7xl px-4 py-20 text-center relative">
          <div className="relative inline-block mb-8 group">
            <img
              src="/avatar.jpg"
              alt="Profile picture"
              className="h-40 w-40 rounded-full object-cover shadow-xl transition-all duration-500 hover:scale-110 hover:rotate-6 md:hover:scale-125 group-hover:shadow-[#357AFF]/50"
            />
            <div className="absolute inset-0 rounded-full border-2 border-[#357AFF] animate-pulse-fast"></div>
            <div className="absolute inset-0 md:hidden">
              <div className="absolute inset-0 rounded-full bg-[#357AFF]/20 animate-ripple"></div>
              <div className="absolute inset-0 rounded-full bg-[#357AFF]/10 animate-ripple-delay"></div>
            </div>
            <div className="absolute -inset-4 bg-gradient-to-r from-[#357AFF] to-purple-600 rounded-full opacity-0 group-hover:opacity-30 blur-xl transition-all duration-500 group-hover:duration-200"></div>
          </div>

          <h1 className="mb-4 text-4xl font-bold text-gray-800 md:text-6xl animate-fade-in hover:text-[#357AFF] transition-all duration-300 relative">
            Trần Mạnh Quân
            <span className="absolute -inset-1 bg-gradient-to-r from-[#357AFF]/20 to-purple-600/20 blur opacity-0 group-hover:opacity-100 transition-all duration-500"></span>
          </h1>

          <div className="flex flex-wrap justify-center gap-6 mt-8">
            <a
              href="#contact"
              className="group relative overflow-hidden rounded-lg bg-[#357AFF] px-8 py-3 text-white transition-all duration-300 hover:bg-[#2E69DE] hover:shadow-xl hover:-translate-y-1 active:scale-95"
            >
              <span className="relative z-10">Liên hệ ngay</span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
              </div>
              <div className="absolute -inset-2 bg-gradient-to-r from-[#357AFF] to-purple-600 opacity-0 group-hover:opacity-30 blur-lg transition-all duration-500"></div>
            </a>
            <a
              href="https://zalo.me/g/your-group-link"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-lg bg-[#0068FF] px-8 py-3 text-white transition-all duration-300 hover:bg-[#0055CC] hover:shadow-xl hover:-translate-y-1"
            >
              <span className="relative z-10">Nhóm Zalo</span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
            </a>
            <a
              href="https://your-second-website.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative overflow-hidden rounded-lg bg-[#22C55E] px-8 py-3 text-white transition-all duration-300 hover:bg-[#16A34A] hover:shadow-xl hover:-translate-y-1"
            >
              <span className="relative z-10">Website của tôi</span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
            </a>
          </div>
        </div>
      </section>

      <section id="skills" className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 to-indigo-50/30 animate-gradient"></div>
        <div className="mx-auto max-w-7xl px-4 relative">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-800 relative">
            Kỹ năng
            <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-[#357AFF] rounded-full"></div>
          </h2>
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              { name: "HTML/CSS", level: "95%", icon: "fa-html5" },
              { name: "JavaScript", level: "90%", icon: "fa-js" },
              { name: "React", level: "85%", icon: "fa-react" },
              { name: "Node.js", level: "80%", icon: "fa-node-js" },
              { name: "TypeScript", level: "75%", icon: "fa-code" },
              { name: "Git", level: "85%", icon: "fa-git-alt" },
            ].map((skill, index) => (
              <div
                key={index}
                className="group rounded-lg bg-white/80 backdrop-blur-sm p-6 shadow-lg transition-all duration-300 hover:shadow-2xl hover:-translate-y-2 relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-[#357AFF]/10 to-purple-600/10 opacity-0 group-hover:opacity-100 transform translate-x-full group-hover:translate-x-0 transition-all duration-700"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent opacity-0 group-hover:opacity-100 animate-shimmer"></div>
                <i
                  className={`fab ${skill.icon} mb-4 text-4xl text-[#357AFF] transition-all duration-300 group-hover:scale-110 group-hover:text-[#2E69DE] relative z-10`}
                ></i>
                <h3 className="mb-2 text-xl font-semibold relative z-10">
                  {skill.name}
                </h3>
                <div className="h-2 rounded-full bg-gray-200/50 backdrop-blur-sm overflow-hidden relative z-10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#357AFF] to-purple-600 transition-all duration-1000 ease-out relative"
                    style={{ width: "0%" }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.width = skill.level;
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="experience" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-800">
            Kinh nghiệm
          </h2>
          <div className="space-y-8">
            {[
              {
                role: "Senior Frontend Developer",
                company: "Tech Company A",
                period: "2022 - Hiện tại",
                description:
                  "Phát triển và duy trì các ứng dụng web quy mô lớn sử dụng React và TypeScript.",
              },
              {
                role: "Frontend Developer",
                company: "Tech Company B",
                period: "2020 - 2022",
                description:
                  "Xây dựng giao diện người dùng responsive và tối ưu hiệu suất website.",
              },
              {
                role: "Junior Developer",
                company: "Tech Company C",
                period: "2019 - 2020",
                description:
                  "Phát triển các component UI và fix bug theo yêu cầu.",
              },
            ].map((exp, index) => (
              <div
                key={index}
                className="group rounded-lg bg-gray-50 p-6 shadow-lg transition-all duration-300 hover:shadow-2xl hover:bg-white"
              >
                <h3 className="mb-2 text-xl font-semibold text-[#357AFF] group-hover:translate-x-2 transition-transform">
                  {exp.role}
                </h3>
                <p className="mb-2 text-gray-600 group-hover:translate-x-2 transition-transform delay-75">
                  {exp.company} | {exp.period}
                </p>
                <p className="text-gray-600 group-hover:translate-x-2 transition-transform delay-100">
                  {exp.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-20">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-gray-800">
            Liên hệ
          </h2>
          <div className="mx-auto max-w-2xl rounded-lg bg-white p-8 shadow-lg hover:shadow-2xl transition-all duration-300">
            <div className="mb-8 grid grid-cols-1 gap-6 md:grid-cols-2">
              <div className="group text-center transition-transform duration-300 hover:scale-105">
                <div className="relative inline-block">
                  <i className="fas fa-envelope mb-4 text-3xl text-[#357AFF] transition-transform duration-300 group-hover:scale-110"></i>
                  <div className="absolute inset-0 animate-ping rounded-full bg-[#357AFF]/20"></div>
                </div>
                <p className="text-gray-600 group-hover:text-[#357AFF] transition-colors">
                  qnet462009@gmail.com
                </p>
              </div>
              <div className="group text-center transition-transform duration-300 hover:scale-105">
                <div className="relative inline-block">
                  <i className="fas fa-phone mb-4 text-3xl text-[#357AFF] transition-transform duration-300 group-hover:scale-110"></i>
                  <div className="absolute inset-0 animate-ping rounded-full bg-[#357AFF]/20"></div>
                </div>
                <p className="text-gray-600 group-hover:text-[#357AFF] transition-colors">
                  0376841471
                </p>
              </div>
            </div>
            <div className="flex justify-center space-x-8">
              {[
                { icon: "fa-facebook", color: "#1877F2" },
                { icon: "fa-linkedin", color: "#0A66C2" },
                { icon: "fa-github", color: "#333" },
                {
                  icon: "fa-users",
                  color: "#0068FF",
                  link: "https://zalo.me/g/your-group-link",
                },
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.link || "#"}
                  target={social.link ? "_blank" : "_self"}
                  rel={social.link ? "noopener noreferrer" : ""}
                  className="group relative"
                >
                  <i
                    className={`fab ${social.icon} text-2xl text-gray-600 transition-all duration-300 group-hover:text-[${social.color}] group-hover:scale-125`}
                  ></i>
                  <div className="absolute -inset-2 rounded-full bg-gray-100 opacity-0 scale-0 group-hover:opacity-100 group-hover:scale-100 transition-all duration-300"></div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-white/80 backdrop-blur-sm py-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-50/30 to-indigo-50/30 animate-gradient"></div>
        <div className="text-center text-gray-600 relative">
          <p>&copy; 2025 Trần Mạnh Quân. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

<style jsx global>{`
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes slide-up {
    from { transform: translateY(40px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }

  @keyframes gradient {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }

  @keyframes ripple {
    0% { transform: scale(0.8); opacity: 1; }
    100% { transform: scale(2); opacity: 0; }
  }

  @keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
  }

  @keyframes click-ring-1 {
    0% { 
      width: 0px; 
      height: 0px; 
      opacity: 0.5;
      border: 2px solid #357AFF;
      border-radius: 50%;
    }
    100% { 
      width: 50px; 
      height: 50px; 
      opacity: 0;
      border: 2px solid #357AFF;
      border-radius: 50%;
    }
  }

  @keyframes click-ring-2 {
    0% { 
      width: 0px; 
      height: 0px; 
      opacity: 0.3;
      background: #357AFF;
      border-radius: 50%;
    }
    100% { 
      width: 30px; 
      height: 30px; 
      opacity: 0;
      background: #357AFF;
      border-radius: 50%;
    }
  }

  @keyframes click-ring-3 {
    0% { 
      width: 0px; 
      height: 0px; 
      opacity: 0.2;
      background: #ffffff;
      border-radius: 50%;
    }
    50% { 
      opacity: 0.1;
    }
    100% { 
      width: 20px; 
      height: 20px; 
      opacity: 0;
      background: #ffffff;
      border-radius: 50%;
    }
  }

  .animate-click-ring-1 {
    position: absolute;
    animation: click-ring-1 0.8s ease-out;
  }

  .animate-click-ring-2 {
    position: absolute;
    animation: click-ring-2 0.6s ease-out;
  }

  .animate-click-ring-3 {
    position: absolute;
    animation: click-ring-3 0.4s ease-out;
  }

  .animate-gradient {
    background-size: 200% 200%;
    animation: gradient 8s ease infinite;
  }

  .animate-fade-in {
    animation: fade-in 1s ease-out;
  }

  .animate-slide-up {
    animation: slide-up 1s ease-out;
  }

  .animate-ripple {
    animation: ripple 2s infinite;
  }

  .animate-shimmer {
    animation: shimmer 2s infinite;
  }

  @media (min-width: 768px) {
    .hover-glow:hover {
      box-shadow: 0 0 25px rgba(53, 122, 255, 0.6);
    }
  }

  @media (max-width: 767px) {
    .touch-pulse:active {
      animation: pulse 0.3s;
    }
  }

  html {
    scroll-behavior: smooth;
  }

  ::-webkit-scrollbar {
    width: 10px;
  }

  ::-webkit-scrollbar-track {
    background: #f1f1f1;
  }

  ::-webkit-scrollbar-thumb {
    background: #357AFF;
    border-radius: 5px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #2E69DE;
  }
`}</style>;

export default MainComponent;