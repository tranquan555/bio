"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const { user } = useUser();
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [uploadError, setUploadError] = useState(null);
  const [sourceUrl, setSourceUrl] = useState("");
  const [checkInterval, setCheckInterval] = useState(3600);
  const [upload, { loading: uploading }] = useUpload();

  const fetchFiles = async () => {
    try {
      const response = await fetch("/api/list-files", { method: "POST" });
      if (!response.ok) {
        throw new Error("Failed to fetch files");
      }
      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setFiles(data.files);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchFiles();
    }
  }, [user]);

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      setUploadError(null);
      const { url, mimeType, error } = await upload({ file });

      if (error) {
        throw new Error(error);
      }

      const response = await fetch("/api/upload-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          file: {
            name: file.name,
            size: file.size,
            type: file.type,
            base64: url,
          },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to save file");
      }

      await fetchFiles();
    } catch (err) {
      setUploadError(err.message);
    }
  };

  const handleAddSource = async (e) => {
    e.preventDefault();
    try {
      setUploadError(null);
      const response = await fetch("/api/add-auto-update-source", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceUrl, checkInterval }),
      });

      if (!response.ok) {
        throw new Error("Failed to add source");
      }

      setSourceUrl("");
      await fetchFiles();
    } catch (err) {
      setUploadError(err.message);
    }
  };

  const checkSources = async () => {
    try {
      setUploadError(null);
      const response = await fetch("/api/check-auto-update-sources", {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("Failed to check sources");
      }

      const data = await response.json();
      if (data.updated > 0) {
        await fetchFiles();
      }
    } catch (err) {
      setUploadError(err.message);
    }
  };

  useEffect(() => {
    if (user) {
      const interval = setInterval(checkSources, 60000); // Check every minute
      return () => clearInterval(interval);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
        <div className="mx-auto max-w-4xl rounded-xl bg-white p-8 shadow-xl">
          <h1 className="mb-6 text-center text-3xl font-bold text-gray-800">
            Welcome to File Storage
          </h1>
          <p className="text-center text-gray-600">
            Please{" "}
            <a href="/account/signin" className="text-blue-600 hover:underline">
              sign in
            </a>{" "}
            or{" "}
            <a href="/account/signup" className="text-blue-600 hover:underline">
              create an account
            </a>{" "}
            to continue.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="mx-auto max-w-6xl space-y-8">
        <div className="flex flex-col items-center justify-between gap-4 rounded-xl bg-white p-6 shadow-xl md:flex-row">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 md:text-3xl">
              Your Files
            </h1>
            <p className="text-gray-600">
              Welcome back, {user.email}!{" "}
              <a
                href="/account/logout"
                className="text-blue-600 hover:underline"
              >
                Sign out
              </a>
            </p>
          </div>
          <div className="flex flex-col gap-4 md:flex-row">
            <label className="flex cursor-pointer items-center rounded-lg bg-blue-600 px-6 py-3 text-white transition hover:bg-blue-700">
              <span className="mr-2">Upload File</span>
              <input
                type="file"
                className="hidden"
                onChange={handleFileUpload}
                disabled={uploading}
              />
            </label>
          </div>
        </div>

        <div className="rounded-xl bg-white p-6 shadow-xl">
          <h2 className="mb-4 text-xl font-semibold text-gray-800">
            Auto-Update Source
          </h2>
          <form onSubmit={handleAddSource} className="space-y-4">
            <div className="flex flex-col gap-4 md:flex-row">
              <input
                type="url"
                value={sourceUrl}
                onChange={(e) => setSourceUrl(e.target.value)}
                placeholder="Enter source URL"
                className="flex-1 rounded-lg border border-gray-300 px-4 py-2"
                required
              />
              <input
                type="number"
                value={checkInterval}
                onChange={(e) => setCheckInterval(Number(e.target.value))}
                placeholder="Check interval (seconds)"
                className="w-full rounded-lg border border-gray-300 px-4 py-2 md:w-48"
                min="60"
                required
              />
              <button
                type="submit"
                className="rounded-lg bg-green-600 px-6 py-2 text-white transition hover:bg-green-700"
              >
                Add Source
              </button>
            </div>
          </form>
        </div>

        {(error || uploadError) && (
          <div className="rounded-lg bg-red-50 p-4 text-red-600">
            {error || uploadError}
          </div>
        )}

        <div className="rounded-xl bg-white p-6 shadow-xl">
          <div className="overflow-x-auto">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-blue-600 border-t-transparent"></div>
              </div>
            ) : files.length === 0 ? (
              <p className="py-8 text-center text-gray-600">
                No files uploaded yet.
              </p>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left">
                    <th className="pb-4 font-semibold text-gray-600">Name</th>
                    <th className="pb-4 font-semibold text-gray-600">Type</th>
                    <th className="pb-4 font-semibold text-gray-600">Size</th>
                    <th className="pb-4 font-semibold text-gray-600">
                      Uploaded
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {files.map((file) => (
                    <tr key={file.id} className="border-b">
                      <td className="py-4">
                        <a
                          href={file.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          {file.file_name}
                        </a>
                      </td>
                      <td className="py-4 text-gray-600">{file.file_type}</td>
                      <td className="py-4 text-gray-600">
                        {(file.file_size / 1024).toFixed(2)} KB
                      </td>
                      <td className="py-4 text-gray-600">
                        {new Date(file.created_at).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;