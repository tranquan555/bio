async function handler({ file }) {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const { url, mimeType, error } = await upload({ base64: file });

    if (error) {
      return { error };
    }

    const [savedFile] = await sql`
      INSERT INTO files (
        user_id,
        file_name,
        file_url,
        file_type,
        file_size
      ) VALUES (
        ${session.user.id},
        ${file.name},
        ${url},
        ${mimeType || "application/octet-stream"},
        ${file.size}
      )
      RETURNING *
    `;

    return { file: savedFile };
  } catch (error) {
    return { error: "Failed to upload file" };
  }
}