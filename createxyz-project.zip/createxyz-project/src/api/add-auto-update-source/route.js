async function handler({ sourceUrl, checkInterval }) {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const [source] = await sql`
      INSERT INTO auto_update_sources (
        user_id,
        source_url,
        check_interval
      ) VALUES (
        ${session.user.id},
        ${sourceUrl},
        ${checkInterval || 3600}
      )
      RETURNING *
    `;

    return { source };
  } catch (error) {
    return { error: "Failed to add source" };
  }
}