async function handler() {
  const session = getSession();

  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const files = await sql`
      SELECT * FROM files 
      WHERE user_id = ${session.user.id}
      ORDER BY created_at DESC
    `;

    return { files };
  } catch (error) {
    return { error: "Failed to fetch files" };
  }
}