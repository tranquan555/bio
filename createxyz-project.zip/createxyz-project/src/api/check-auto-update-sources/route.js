async function handler() {
  const session = getSession();
  if (!session?.user?.id) {
    return { error: "Unauthorized" };
  }

  try {
    const sources = await sql`
      SELECT * FROM auto_update_sources 
      WHERE user_id = ${session.user.id}
      AND (CURRENT_TIMESTAMP - last_checked) > (check_interval || ' seconds')::interval
    `;

    const results = [];
    for (const source of sources) {
      try {
        const response = await fetch(source.source_url);
        const text = await response.text();

        const urlRegex = /(https?:\/\/[^\s<>"']+?\.(jpg|jpeg|png|gif|webp))/gi;
        const urls = [...new Set(text.match(urlRegex) || [])];

        const existingFiles = await sql`
          SELECT file_url FROM files 
          WHERE user_id = ${session.user.id}
          AND file_url = ANY(${urls})
        `;

        const existingUrls = new Set(existingFiles.map((f) => f.file_url));
        const newUrls = urls.filter((url) => !existingUrls.has(url));

        for (const url of newUrls) {
          const { url: uploadedUrl, mimeType, error } = await upload({ url });

          if (!error) {
            const [file] = await sql`
              INSERT INTO files (
                user_id,
                file_name,
                file_url,
                file_type,
                file_size
              ) VALUES (
                ${session.user.id},
                ${url.split("/").pop()},
                ${uploadedUrl},
                ${mimeType || "image/jpeg"},
                0
              )
              RETURNING *
            `;
            results.push(file);
          }
        }

        await sql`
          UPDATE auto_update_sources 
          SET last_checked = CURRENT_TIMESTAMP
          WHERE id = ${source.id}
        `;
      } catch (error) {
        console.error(`Error processing source ${source.id}:`, error);
      }
    }

    return {
      updated: results.length,
      files: results,
    };
  } catch (error) {
    return { error: "Failed to check sources" };
  }
}